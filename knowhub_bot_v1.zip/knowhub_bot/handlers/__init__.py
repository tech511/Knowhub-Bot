from aiogram import Dispatcher
from handlers.start import router as start_router
from handlers.entries import router as entries_router
from handlers.search import router as search_router
from handlers.callbacks import router as callbacks_router
from handlers.admin import router as admin_router


def setup_routers(dp: Dispatcher):
    for router in (start_router, entries_router, search_router, callbacks_router, admin_router):
        dp.include_router(router)
